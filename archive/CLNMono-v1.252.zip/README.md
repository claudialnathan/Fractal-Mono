# CLN Mono

CLN Mono is a monospaced typeface designed and directed by Claudia Nathan. It is built for code, systems work, and compact interface typography, with a calm industrial character, open counters, decisive terminals, and a strict fixed cell.

Version `1.252` redraws the uppercase `K` with the requested bridge-and-junction construction while preserving the approved metrics, spacing, features, and every other letterform from `1.251`.

## Design

- **Character:** gentle brutalism — a rational skeleton balanced by open apertures, rounded bowls, and restrained machine-age cues.
- **Proportions:** `1000` UPM, `680` cap height, `528` x-height, `728` lowercase ascenders, and `-195` lowercase descenders. The body stays generous at coding sizes without inflating caps or line metrics.
- **Regular weight:** CSS `400` carries approximately `80`-unit stems. The continuous weight axis spans `100` Thin through `800` ExtraBold.
- **Fitting:** every spacing glyph uses a `579`-unit advance. Ink widths and sidebearings are optically fitted inside that invariant frame; `l` is narrowed to `87%`, `m` to `97%`, and `j` is shifted `+60` units to balance the `i–j–k–l` rhythm.
- **Letter construction:** a bridged uppercase `K` with an outward diagonal junction, open `k`, short-hooked `t`, angular-pinched `w`, and an `r` with a rising shoulder, open counter, and diagonal terminal form the family’s protected style anchors.
- **Numerals and dotted letters:** `O`, `o`, and `0` use centre dots by default. The zero keeps the widest dot, while lowercase `o` scales the same contour to `82%`.
- **Symbols:** compact brackets and braces, measured angle brackets, a raised `@`, balanced arithmetic signs, and tall but line-fitting slashes.
- **Programming ligatures:** the family contains `153` base programming definitions. None are automatic; `150` joined drawings are available under `dlig`, while three legacy patterns remain deliberately literal. Equality, arrows, markup, comments, pipes, and punctuation render exactly as typed unless `dlig` is enabled.
- **Rasterisation:** the transformed outlines are intentionally unhinted. The `gasp` table requests grayscale and symmetric smoothing without contradictory grid fitting.
- **Weights:** Thin, ExtraLight, Light, Regular, Book (`450`), Medium, SemiBold, Bold, and ExtraBold.

## Included

- `fonts/desktop/CLNMono-Variable[wght].ttf` — variable desktop font
- `fonts/desktop/CLNMono-*.ttf` — nine static desktop weights
- `fonts/web/CLNMono-Variable.woff2` and `.woff` — variable web fonts
- `fonts/web/CLNMono-*.woff2` and `.woff` — nine static web weights
- `cln-mono.css` — variable-font setup for the web
- `specimen.html` — interactive specimen and technical factsheet
- `specimen.css` and `specimen.js` — self-contained presentation and interaction
- `specimen-data.js` — verified data generated from the release font
- `ligature-specimen.html` — coding-ligature proof
- `ligature-audit.html` — complete shaped-versus-literal catalog
- `code-example.html` — realistic code-editor specimen
- `specimens/` — PNG and PDF proofs of CLN Mono’s weights, construction, fitting, and release refinements
- `build-report.json` — release metrics, file sizes, and SHA-256 hashes
- `source/DESIGN_NOTES.md` — CLN Mono’s design decisions and release history
- `source/` — reproducible build, validation, and specimen scripts
- `archive/` — recoverable copies of previous releases

The family contains 1,743 glyphs, including 163 programming-ligature glyphs and 1,363 encoded characters across Latin, Cyrillic, Greek, symbols, and code-oriented alternates. The variable fonts retain `avar`, `STAT`, and `gasp` tables so weight mapping, style linking, and rasterisation intent remain explicit.

## Install

On macOS, open `fonts/desktop/CLNMono-Variable[wght].ttf` in Font Book and choose **Install**. Use the variable file by itself, or install the individual static weights instead; do not install both sets at the same time because applications can show duplicate styles.

For the web, copy `fonts/web/CLNMono-Variable.woff2` and use the supplied `cln-mono.css`:

```css
@font-face {
  font-family: "CLN Mono";
  src:
    url("./fonts/web/CLNMono-Variable.woff2") format("woff2") tech("variations"),
    url("./fonts/web/CLNMono-Variable.woff2") format("woff2-variations");
  font-style: normal;
  font-weight: 100 800;
  font-display: swap;
}

.cln-mono {
  font-family: "CLN Mono", monospace;
  font-synthesis: none;
  font-variant-ligatures: none;
}
```

Set ordinary weights with `font-weight: 450`; no raw `font-variation-settings` declaration is needed for the standard `wght` axis. The supplied utility keeps programming ligatures off, while `.cln-mono-programming-ligatures` enables the discretionary `dlig` drawings.

## Rebuild and validate

The build requires Python 3, FontTools, Brotli, Pillow, and HarfBuzz (`hb-shape`). The configured OFL source master path is declared in `source/build.py`.

```sh
python3 source/build.py
python3 source/validate.py
python3 source/specimens.py
python3 source/ligature_audit.py
python3 source/desktop_specimen.py
python3 source/factsheet_data.py
node source/browser_specimens.mjs
```

`build.py --quick` regenerates only the variable TTF for fast design iteration.

`source/factsheet_data.py` reads the variable TTF, `build-report.json`, and the checked-in `source/language-support.json` snapshot to regenerate the public specimen data. Language coverage uses Hyperglot’s base-character check for primary, draft-or-better orthographies of living and constructed languages; it is an estimate, not native editorial review.

## Scope

This release is roman/upright only. It has no italic, optical-size, or width axis. Modern macOS and browser rendering are the primary targets. Validation covers all 30 font files, shaping, cell preservation, weight interpolation, optical control glyphs, repeat guards, vertical metrics, anti-aliasing metadata, hashes, and browser proofs at 1× and 2×.

## Authorship and licence

CLN Mono is designed and directed by **Claudia Nathan**. Copyright 2026 Claudia Nathan.

The Font Software is distributed under the SIL Open Font License 1.1. The complete licence and required copyright notices for inherited OFL components are retained in `OFL.txt`; those notices satisfy redistribution requirements and do not replace CLN Mono’s design authorship.
