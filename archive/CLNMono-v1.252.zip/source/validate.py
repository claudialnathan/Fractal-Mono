#!/usr/bin/env python3
"""Structural validation for the CLN Mono release files."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import tempfile
import unicodedata
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile

from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont


PROJECT = Path(__file__).resolve().parents[1]
DESKTOP = PROJECT / "fonts" / "desktop"
WEB = PROJECT / "fonts" / "web"
VARIABLE = DESKTOP / "CLNMono-Variable[wght].ttf"
BUILD_REPORT = PROJECT / "build-report.json"
PREVIOUS_RELEASE = PROJECT / "archive" / "CLNMono-v1.251.zip"
CLEAN_RELEASE = PROJECT / "archive" / "CLNMono-v1.230.zip"
DEFECTIVE_RELEASE = PROJECT / "archive" / "CLNMono-v1.240.zip"

VERSION = "1.252"
CAP_HEIGHT = 680
X_HEIGHT = 528
LOWERCASE_ASCENDER_HEIGHT = 728
ADVANCE = 579
LOWERCASE_O_DOT_SCALE = 0.82
REGULAR_STEM_RANGE = range(77, 84)
ALWAYS_LITERAL_LIGATURE_SEQUENCES = {"/\\", "\\/", "|||"}
HINTING_TABLES = {"cvt ", "fpgm", "prep", "hdmx", "LTSH", "VDMX"}


def family_name(font: TTFont) -> str:
    for record in font["name"].names:
        if record.nameID == 16 and record.platformID == 3:
            return record.toUnicode()
    raise AssertionError("Missing typographic family name")


def version_name(font: TTFont) -> str:
    for record in font["name"].names:
        if record.nameID == 5 and record.platformID == 3:
            return record.toUnicode()
    raise AssertionError("Missing version name")


def glyph_signature(font: TTFont, glyph_name: str) -> tuple[tuple[int, int], ...]:
    glyph = font["glyf"][glyph_name]
    coordinates, _, _ = glyph.getCoordinates(font["glyf"])
    return tuple(coordinates)


def glyph_bounds(font: TTFont, glyph_name: str) -> tuple[int, int, int, int]:
    glyph = font["glyf"][glyph_name]
    glyph.recalcBounds(font["glyf"])
    return glyph.xMin, glyph.yMin, glyph.xMax, glyph.yMax


def contour_signature(
    font: TTFont,
    glyph_name: str,
    contour_index: int,
) -> tuple[tuple[int, int], ...]:
    glyph = font["glyf"][glyph_name]
    start = 0 if contour_index == 0 else glyph.endPtsOfContours[contour_index - 1] + 1
    end = glyph.endPtsOfContours[contour_index]
    return tuple(glyph.coordinates[start : end + 1])


def contour_bounds(
    font: TTFont,
    glyph_name: str,
    contour_index: int,
) -> tuple[int, int, int, int]:
    coordinates = contour_signature(font, glyph_name, contour_index)
    return (
        min(x for x, _ in coordinates),
        min(y for _, y in coordinates),
        max(x for x, _ in coordinates),
        max(y for _, y in coordinates),
    )


def shape(text: str, features: str | None = None) -> str:
    harfbuzz = shutil.which("hb-shape")
    assert harfbuzz, "hb-shape is required for programming-ligature validation"
    command = [harfbuzz, str(VARIABLE), "--variations=wght=400"]
    if features:
        command.append(f"--features={features}")
    command.extend(["--", text])
    return subprocess.check_output(command, text=True).strip()


def shape_file(path: Path, text: str, features: str | None = None) -> str:
    harfbuzz = shutil.which("hb-shape")
    assert harfbuzz, "hb-shape is required for release-file validation"

    def run(shape_path: Path) -> str:
        command = [harfbuzz, str(shape_path)]
        if "Variable" in path.name:
            command.append("--variations=wght=400")
        if features:
            command.append(f"--features={features}")
        command.extend(["--", text])
        return subprocess.check_output(command, text=True).strip()

    if path.suffix == ".ttf":
        return run(path)

    # HarfBuzz's CLI build on this machine does not open WOFF containers
    # directly. Decompress each web font to a temporary SFNT and shape that
    # exact table set instead of skipping web-output validation.
    with tempfile.TemporaryDirectory(prefix="cln-font-validate-") as directory:
        temporary_path = Path(directory) / f"{path.stem}.ttf"
        font = TTFont(path)
        font.flavor = None
        font.save(temporary_path)
        return run(temporary_path)


def main() -> None:
    font_paths = sorted(DESKTOP.glob("*.ttf")) + sorted(WEB.glob("*.woff")) + sorted(WEB.glob("*.woff2"))
    assert len(font_paths) == 30, f"Expected 30 font files, found {len(font_paths)}"
    report = json.loads(BUILD_REPORT.read_text())
    assert report["version"] == VERSION
    assert report["metrics"]["lowercaseAscenderHeight"] == LOWERCASE_ASCENDER_HEIGHT
    assert report["curveRepair"] == {
        "method": "restore established quadratic controls",
        "removed": "v1.240 contour-local off-curve tension",
        "scope": "all established letters and numerals",
        "preserves": [
            "metrics",
            "optical fitting",
            "zone remap",
            "custom k/r/t/w outlines",
            "variable interpolation",
        ],
    }
    assert report["dottedLetters"] == {
        "default": ["O", "o"],
        "sourceContour": "zero centre dot",
        "lowercaseScale": LOWERCASE_O_DOT_SCALE,
    }
    assert report["slashVerticalScale"] == 0.94
    assert report["apparentSize"] == {
        "strategy": "raise lowercase ascenders without enlarging x-height or line metrics",
        "characters": ["b", "d", "f", "h", "l"],
        "sharedSquareDotTarget": LOWERCASE_ASCENDER_HEIGHT,
        "target": LOWERCASE_ASCENDER_HEIGHT,
    }
    assert report["designer"] == "Claudia Nathan"
    assert report["designDirection"] == "CLN"
    assert report["defaultProgrammingLigatures"] == "none"
    assert report["optionalProgrammingFeature"] == "dlig"
    assert len(report["defaultLiteralProgrammingSequences"]) == 153
    assert len(report["optionalProgrammingSequences"]) == 150
    assert set(report["alwaysLiteralProgrammingSequences"]) == ALWAYS_LITERAL_LIGATURE_SEQUENCES
    assert report["rasterization"] == {
        "hinting": "unhinted transformed outlines",
        "gaspVersion": 1,
        "gaspRange": {"65535": 10},
        "behavior": "grayscale and symmetric smoothing without grid fitting",
    }
    assert set(report["files"]) == {
        str(path.relative_to(PROJECT)) for path in font_paths
    }
    for path in font_paths:
        relative_path = str(path.relative_to(PROJECT))
        assert report["files"][relative_path]["bytes"] == path.stat().st_size
        assert report["files"][relative_path]["sha256"] == hashlib.sha256(path.read_bytes()).hexdigest()

    for path in font_paths:
        font = TTFont(path, lazy=False)
        assert family_name(font) == "CLN Mono", path
        assert version_name(font) == f"Version {VERSION}", path
        assert round(font["head"].fontRevision, 3) == float(VERSION), path
        assert font["head"].unitsPerEm == 1000, path
        assert font["OS/2"].sxHeight == X_HEIGHT, path
        assert font["OS/2"].sCapHeight == CAP_HEIGHT, path
        assert font["OS/2"].fsSelection & (1 << 7), f"USE_TYPO_METRICS missing in {path}"
        assert (font["hhea"].ascent, font["hhea"].descent, font["hhea"].lineGap) == (
            font["OS/2"].sTypoAscender,
            font["OS/2"].sTypoDescender,
            font["OS/2"].sTypoLineGap,
        ), path
        assert font["gasp"].version == 1, path
        assert font["gasp"].gaspRange == {65535: 10}, path
        assert not (HINTING_TABLES & set(font.keys())), path
        assert len(font.getBestCmap()) >= 1360, path
        assert font["glyf"]["O"].numberOfContours == 3, path
        assert font["glyf"]["o"].numberOfContours == 3, path
        r_name = font.getBestCmap()[ord("r")]
        r_coordinates, _, _ = font["glyf"][r_name].getCoordinates(font["glyf"])
        assert len(r_coordinates) == 28, f"CLN r construction missing from {path}"
        font.close()

        for sequence in (
            "===",
            "!==",
            "=>",
            "->",
            "-->",
            "<->",
            "<==>",
            ">=",
            "<=",
            "--",
            "<<",
            ">>",
            "||",
            "</>",
            "<>",
            "//",
            "...",
            ":::",
        ):
            result = shape_file(path, sequence)
            assert ".liga" not in result, (path, sequence, result)
            assert result.count(f"+{ADVANCE}") == len(sequence), (path, sequence, result)

        for sequence, glyph_name in {
            "===": "equal_equal_equal.liga",
            "!==": "exclam_equal_equal.liga",
            "=>": "equal_greater.liga",
            "->": "hyphen_greater.liga",
            ">=": "greater_equal.liga",
            "<=": "less_equal.liga",
            "</>": "less_slash_greater.liga",
            "<>": "less_greater.liga",
            "//": "slash_slash.liga",
            "...": "period_period_period.liga",
            ":::": "colon_colon_colon.liga",
        }.items():
            result = shape_file(path, sequence, "dlig=1")
            assert glyph_name in result, (path, sequence, result)
            assert result.count(f"+{ADVANCE}") == len(sequence), (path, sequence, result)

    variable = TTFont(VARIABLE)
    axes = {axis.axisTag: axis for axis in variable["fvar"].axes}
    assert set(axes) == {"wght"}
    assert (axes["wght"].minValue, axes["wght"].defaultValue, axes["wght"].maxValue) == (100, 400, 800)
    instance_weights = {round(instance.coordinates["wght"]) for instance in variable["fvar"].instances}
    assert instance_weights == {100, 200, 300, 400, 450, 500, 600, 700, 800}
    for tag in ("avar", "STAT", "gasp"):
        assert tag in variable, f"Missing {tag} table"
    feature_records = variable["GSUB"].table.FeatureList.FeatureRecord
    dlig_features = [record.Feature for record in feature_records if record.FeatureTag == "dlig"]
    calt_features = [record.Feature for record in feature_records if record.FeatureTag == "calt"]
    assert len(dlig_features) == 1
    assert dlig_features[0].LookupCount == 152
    assert len(calt_features) == 1
    assert calt_features[0].LookupCount == 2

    cmap = variable.getBestCmap()
    for codepoint in range(0x20, 0x7F):
        glyph_name = cmap[codepoint]
        assert variable["hmtx"].metrics[glyph_name][0] == ADVANCE, chr(codepoint)

    thin = instantiateVariableFont(variable, {"wght": 100}, inplace=False)
    regular = instantiateVariableFont(variable, {"wght": 400}, inplace=False)
    book = instantiateVariableFont(variable, {"wght": 450}, inplace=False)
    extra_bold = instantiateVariableFont(variable, {"wght": 800}, inplace=False)

    # The custom k/r/t/w drawings remain immutable design anchors. Compare
    # their actual variable instances with the immediately preceding release
    # rather than relying only on bounds or point counts.
    assert PREVIOUS_RELEASE.exists(), "Missing v1.251 regression archive"
    with ZipFile(PREVIOUS_RELEASE) as archive:
        previous_variable = TTFont(
            BytesIO(
                archive.read(
                    "fonts/desktop/CLNMono-Variable[wght].ttf"
                )
            )
        )
    for weight, current_instance in (
        (100, thin),
        (400, regular),
        (800, extra_bold),
    ):
        previous_instance = instantiateVariableFont(
            previous_variable,
            {"wght": weight},
            inplace=False,
        )
        for glyph_name in ("k", "r", "t", "w"):
            assert glyph_signature(
                current_instance, glyph_name
            ) == glyph_signature(previous_instance, glyph_name), (
                f"Locked {glyph_name} outline changed at wght {weight}"
            )

    # v1.252 intentionally replaces the pinched three-contour uppercase K with
    # the requested bridge-and-junction construction. The single compatible
    # contour must interpolate cleanly across the axis while cap height,
    # advance, and every other family metric remain unchanged.
    expected_k_bounds = {
        100: (100, 0, 530, CAP_HEIGHT),
        400: (86, 0, 545, CAP_HEIGHT),
        800: (55, 0, 565, CAP_HEIGHT),
    }
    for weight, current_instance in (
        (100, thin),
        (400, regular),
        (800, extra_bold),
    ):
        previous_instance = instantiateVariableFont(
            previous_variable,
            {"wght": weight},
            inplace=False,
        )
        k_glyph = current_instance["glyf"]["K"]
        assert k_glyph.numberOfContours == 1, (
            f"K must use one connected contour at wght {weight}"
        )
        assert len(k_glyph.coordinates) == 13, (
            f"K must keep 13-point interpolation topology at wght {weight}"
        )
        assert glyph_bounds(current_instance, "K") == expected_k_bounds[weight]
        assert glyph_signature(
            current_instance, "K"
        ) != glyph_signature(previous_instance, "K"), (
            f"K did not change from the pinched v1.251 outline at wght {weight}"
        )

    # v1.240's off-curve-only tension pass caused the reported dents. Restored
    # established outlines must exactly match the last clean source geometry at
    # all three axis anchors. O/o add one dot contour after that clean outline.
    assert CLEAN_RELEASE.exists(), "Missing v1.230 clean-curve archive"
    with ZipFile(CLEAN_RELEASE) as archive:
        clean_variable = TTFont(
            BytesIO(
                archive.read(
                    "fonts/desktop/CLNMono-Variable[wght].ttf"
                )
            )
        )
    assert DEFECTIVE_RELEASE.exists(), "Missing v1.240 regression archive"
    with ZipFile(DEFECTIVE_RELEASE) as archive:
        defective_variable = TTFont(
            BytesIO(
                archive.read(
                    "fonts/desktop/CLNMono-Variable[wght].ttf"
                )
            )
        )
    restored_glyphs = (
        "a",
        "c",
        "e",
        "g",
        "m",
        "n",
        "p",
        "q",
        "six",
        "nine",
        "M",
        "N",
        "Q",
        "S",
        "V",
        "W",
        "X",
        "x",
        "s",
        "zero",
        "eight",
    )
    preserved_letter_numeral_glyphs: set[str] = set()
    for weight, current_instance in (
        (100, thin),
        (400, regular),
        (800, extra_bold),
    ):
        clean_instance = instantiateVariableFont(
            clean_variable,
            {"wght": weight},
            inplace=False,
        )
        defective_instance = instantiateVariableFont(
            defective_variable,
            {"wght": weight},
            inplace=False,
        )
        for glyph_name in restored_glyphs:
            assert glyph_signature(
                current_instance, glyph_name
            ) == glyph_signature(clean_instance, glyph_name), (
                f"{glyph_name} did not restore its clean curve at wght {weight}"
            )
            assert glyph_signature(
                current_instance, glyph_name
            ) != glyph_signature(defective_instance, glyph_name), (
                f"{glyph_name} retained the v1.240 dent at wght {weight}"
            )
        for glyph_name in ("O", "o"):
            clean_coordinates = glyph_signature(clean_instance, glyph_name)
            current_coordinates = glyph_signature(current_instance, glyph_name)
            assert current_coordinates[: len(clean_coordinates)] == clean_coordinates, (
                f"{glyph_name} base outline changed at wght {weight}"
            )
            assert len(current_coordinates) == len(clean_coordinates) + 12

        assert contour_signature(current_instance, "O", 2) == contour_signature(
            current_instance, "zero", 2
        ), f"O dot diverged from zero at wght {weight}"

        # The repair may change quadratic controls, but not bounds,
        # advances, or contour topology. At Regular it also preserves every
        # explicit anchor; v1.240's unadjusted gvar deltas could shift implied
        # interpolation at non-default weights, which the clean restoration is
        # intentionally allowed to correct. Audit the complete encoded
        # letter/number repertoire, not only the glyphs named in the report.
        current_cmap = current_instance.getBestCmap()
        defective_cmap = defective_instance.getBestCmap()
        letter_numeral_names = {
            current_cmap[codepoint]
            for codepoint in current_cmap.keys() & defective_cmap.keys()
            if unicodedata.category(chr(codepoint))[0] in {"L", "N"}
        }
        intentional_k_family = {
            glyph_name
            for glyph_name in letter_numeral_names
            if glyph_name == "K"
            or (
                current_instance["glyf"][glyph_name].isComposite()
                and any(
                    component.glyphName == "K"
                    for component in current_instance["glyf"][glyph_name].components
                )
            )
        }
        assert intentional_k_family == {
            "K",
            "Kappa",
            "uni0136",
            "uni040C",
            "uni041A",
        }
        preserved_letter_numeral_glyphs.update(letter_numeral_names)
        for glyph_name in letter_numeral_names:
            current_glyph = current_instance["glyf"][glyph_name]
            defective_glyph = defective_instance["glyf"][glyph_name]
            current_metrics = current_instance["hmtx"].metrics[glyph_name]
            defective_metrics = defective_instance["hmtx"].metrics[glyph_name]
            assert current_metrics[0] == defective_metrics[0], (
                glyph_name,
                weight,
                "advance",
            )
            if glyph_name in intentional_k_family:
                continue
            if weight == 400:
                assert current_metrics == defective_metrics, (
                    glyph_name,
                    weight,
                    "metrics",
                )
                assert glyph_bounds(current_instance, glyph_name) == glyph_bounds(
                    defective_instance, glyph_name
                ), (glyph_name, weight, "bounds")
            if current_glyph.isComposite() or defective_glyph.isComposite():
                assert current_glyph.isComposite() == defective_glyph.isComposite()
                continue
            if current_glyph.numberOfContours <= 0 or defective_glyph.numberOfContours <= 0:
                assert current_glyph.numberOfContours == defective_glyph.numberOfContours
                continue
            defective_point_count = len(defective_glyph.coordinates)
            expected_extra = 12 if glyph_name in {"O", "o"} else 0
            assert len(current_glyph.coordinates) == defective_point_count + expected_extra, (
                glyph_name,
                weight,
                "point count",
            )
            assert current_glyph.endPtsOfContours[: defective_glyph.numberOfContours] == (
                defective_glyph.endPtsOfContours
            ), (glyph_name, weight, "contour topology")
            for index in range(defective_point_count):
                assert (current_glyph.flags[index] & 1) == (
                    defective_glyph.flags[index] & 1
                ), (glyph_name, weight, index, "point type")
                if weight == 400 and defective_glyph.flags[index] & 1:
                    assert current_glyph.coordinates[index] == (
                        defective_glyph.coordinates[index]
                    ), (glyph_name, weight, index, "on-curve anchor")

    assert contour_bounds(regular, "zero", 2) == (230, 300, 349, 405)
    assert contour_bounds(regular, "O", 2) == (230, 300, 349, 405)
    assert contour_bounds(regular, "o", 2) == (241, 220, 338, 307)
    assert glyph_bounds(regular, "slash") == (78, -80, 501, 738)
    assert glyph_bounds(regular, "backslash") == (78, -80, 501, 738)

    for glyph_name in (
        "H",
        "a",
        "K",
        "t",
        "k",
        "r",
        "w",
        "zero",
        "at",
        "braceleft",
        "less_equal.liga",
        "greater_equal.liga",
        "less_slash.liga",
        "slash_greater.liga",
        "less_slash_greater.liga",
        "less_greater.liga",
        "hyphen_greater.liga",
        "hyphen_hyphen_greater.liga",
        "less_hyphen_greater.liga",
        "equal_greater.liga",
        "less_equal_greater.liga",
    ):
        signatures = {
            glyph_signature(thin, glyph_name),
            glyph_signature(book, glyph_name),
            glyph_signature(extra_bold, glyph_name),
        }
        assert len(signatures) == 3, f"Weight interpolation is frozen for {glyph_name}"

    h_coordinates, _, _ = regular["glyf"]["H"].getCoordinates(regular["glyf"])
    h_x = sorted({x for x, _ in h_coordinates})
    h_stem = h_x[1] - h_x[0]
    assert h_stem in REGULAR_STEM_RANGE, f"Unexpected Regular H stem: {h_stem}"

    h_y = {y for _, y in h_coordinates}
    assert max(h_y) == CAP_HEIGHT, f"H cap height: {max(h_y)}"
    h_horizontal_stem = sorted(h_y)[-2] - sorted(h_y)[1]
    assert h_horizontal_stem < h_stem, (
        "Horizontal strokes should be optically lighter than vertical strokes",
        h_horizontal_stem,
        h_stem,
    )
    x_coordinates, _, _ = regular["glyf"]["x"].getCoordinates(regular["glyf"])
    assert max(y for _, y in x_coordinates) == X_HEIGHT, "x-height drifted"
    assert glyph_bounds(regular, "O")[1] < 0
    assert glyph_bounds(regular, "O")[3] > CAP_HEIGHT
    assert glyph_bounds(regular, "o")[1] < 0
    assert glyph_bounds(regular, "o")[3] > X_HEIGHT
    for glyph_name, maximum_sidebearing_delta in (("H", 0), ("O", 0), ("n", 2), ("o", 0)):
        bounds = glyph_bounds(regular, glyph_name)
        left = bounds[0]
        right = ADVANCE - bounds[2]
        assert abs(left - right) <= maximum_sidebearing_delta, (
            glyph_name,
            left,
            right,
        )

    r_bounds = glyph_bounds(regular, "r")
    t_bounds = glyph_bounds(regular, "t")
    k_bounds = glyph_bounds(regular, "k")
    w_bounds = glyph_bounds(regular, "w")
    l_bounds = glyph_bounds(regular, "l")
    m_bounds = glyph_bounds(regular, "m")
    j_bounds = glyph_bounds(regular, "j")
    assert r_bounds == (120, 0, 501, X_HEIGHT), f"Unexpected r fit: {r_bounds}"
    assert ADVANCE - r_bounds[2] == 78, "r right sidebearing drifted"
    for instance, target_stem in ((thin, 50), (regular, 80), (extra_bold, 150)):
        r_coordinates, _, _ = instance["glyf"]["r"].getCoordinates(instance["glyf"])
        assert len(r_coordinates) == 28, "CLN r topology changed"
        observed_stem = r_coordinates[26][0] - r_coordinates[27][0]
        assert abs(observed_stem - target_stem) <= 1, (
            target_stem,
            observed_stem,
        )
        assert glyph_bounds(instance, "r")[3] == X_HEIGHT
    assert t_bounds == (63, 0, 503, 651), f"Unexpected t fit: {t_bounds}"
    assert k_bounds == (104, 0, 522, CAP_HEIGHT), f"Unexpected k fit: {k_bounds}"
    assert w_bounds == (47, 0, 533, X_HEIGHT), f"Unexpected w fit: {w_bounds}"
    for instance in (thin, regular, extra_bold):
        expected_topologies = {"t": 20, "k": 12, "w": 16}
        for glyph_name, point_count in expected_topologies.items():
            coordinates, _, _ = instance["glyf"][glyph_name].getCoordinates(instance["glyf"])
            assert len(coordinates) == point_count, (glyph_name, len(coordinates))
    assert j_bounds == (
        139,
        -195,
        486,
        LOWERCASE_ASCENDER_HEIGHT,
    ), f"Unexpected j fit: {j_bounds}"
    assert l_bounds == (
        84,
        0,
        508,
        LOWERCASE_ASCENDER_HEIGHT,
    ), f"Unexpected l fit: {l_bounds}"
    for glyph_name in ("b", "d", "f", "h", "i", "j", "l"):
        assert glyph_bounds(regular, glyph_name)[3] == LOWERCASE_ASCENDER_HEIGHT, (
            glyph_name,
            glyph_bounds(regular, glyph_name),
        )
    assert m_bounds == (60, 0, 519, 536), f"Unexpected m fit: {m_bounds}"

    ligature_names = [name for name in variable.getGlyphOrder() if ".liga" in name]
    assert len(ligature_names) >= 160, "Programming-ligature coverage shrank"
    for glyph_name in ligature_names:
        assert variable["hmtx"].metrics[glyph_name][0] == ADVANCE, glyph_name

    # Audit the complete programming-ligature inventory rather than a small
    # hand-picked sample. Glyph names encode their source sequence (for example
    # less_slash_greater.liga -> </>), which lets us verify shaping, cell
    # preservation, and ink containment exhaustively.
    reverse_ascii = {
        glyph_name: chr(codepoint)
        for codepoint, glyph_name in variable.getBestCmap().items()
        if 0x20 <= codepoint < 0x7F
    }
    base_ligatures = [
        name for name in ligature_names if ".liga." not in name
    ]
    optional_ligatures = 0
    for glyph_name in base_ligatures:
        tokens = glyph_name.split(".liga")[0].split("_")
        sequence = "".join(reverse_ascii[token] for token in tokens)
        result = shape(sequence)
        assert result.count(f"+{ADVANCE}") == len(sequence), (
            sequence,
            result,
        )
        assert ".liga" not in result, (sequence, glyph_name, result)
        optional_result = shape(sequence, "dlig=1")
        if sequence not in ALWAYS_LITERAL_LIGATURE_SEQUENCES:
            assert glyph_name in optional_result, (
                sequence,
                glyph_name,
                optional_result,
            )
            assert optional_result.count(f"+{ADVANCE}") == len(sequence)
            optional_ligatures += 1
        else:
            assert glyph_name not in optional_result, (sequence, glyph_name, optional_result)

        bounds = glyph_bounds(regular, glyph_name)
        source_run_left = -(len(sequence) - 1) * ADVANCE
        assert bounds[0] >= source_run_left - 24, (sequence, bounds)
        assert bounds[2] <= ADVANCE + 24, (sequence, bounds)

    assert len(base_ligatures) == 153
    assert optional_ligatures == 150

    expected_optional_shapes = {
        "==": "equal_equal.liga",
        "===": "equal_equal_equal.liga",
        "!=": "exclam_equal.liga",
        "!==": "exclam_equal_equal.liga",
        "<=": "less_equal.liga",
        ">=": "greater_equal.liga",
        "->": "hyphen_greater.liga",
        "-->": "hyphen_hyphen_greater.liga",
        "<-": "less_hyphen.liga",
        "<--": "less_hyphen_hyphen.liga",
        "<->": "less_hyphen_greater.liga",
        "=>": "equal_greater.liga",
        "==>": "equal_equal_greater.liga",
        "<==": "less_equal_equal.liga",
        "<=>": "less_equal_greater.liga",
        "<==>": "less_equal_equal_greater.liga",
        "</": "less_slash.liga",
        "/>": "slash_greater.liga",
        "</>": "less_slash_greater.liga",
        "//": "slash_slash.liga",
        "...": "period_period_period.liga",
        ":::": "colon_colon_colon.liga",
    }
    for text, glyph_name in expected_optional_shapes.items():
        default_result = shape(text)
        assert ".liga" not in default_result, (
            f"{text!r} should remain literal by default: {default_result}"
        )
        optional_result = shape(text, "dlig=1")
        assert glyph_name in optional_result, (
            f"{text!r} did not use {glyph_name}: {optional_result}"
        )
        assert optional_result.count(f"+{ADVANCE}") == len(text), (
            f"{text!r} lost its cell grid: {optional_result}"
        )

    for text in ("====", "////", "....", "||||"):
        for features in (None, "dlig=1"):
            result = shape(text, features)
            assert ".liga" not in result, (
                f"Long repeated sequence ligated unexpectedly ({features}): {result}"
            )

    assert glyph_bounds(regular, "less_equal.liga") == (-276, 36, 265, 555)
    assert glyph_bounds(regular, "greater_equal.liga") == (-265, 36, 276, 555)
    assert glyph_bounds(regular, "less_slash.liga") == (-531, 44, 464, 587)
    assert glyph_bounds(regular, "slash_greater.liga") == (-464, 44, 531, 587)
    assert glyph_bounds(regular, "less_slash_greater.liga") == (-1110, 44, 531, 587)
    assert glyph_bounds(regular, "less_greater.liga") == (-531, 44, 531, 587)
    assert glyph_bounds(regular, "hyphen_greater.liga") == (-371, 109, 371, 551)
    assert glyph_bounds(regular, "hyphen_hyphen_greater.liga") == (-701, 109, 122, 551)
    assert glyph_bounds(regular, "less_hyphen_greater.liga") == (-701, 109, 122, 551)
    assert glyph_bounds(regular, "equal_greater.liga") == (-371, 109, 371, 551)
    assert glyph_bounds(regular, "less_equal_equal_greater.liga") == (-1030, 109, -128, 551)

    print(f"PASS: {len(font_paths)} font files parse successfully")
    print("PASS: build report size/hash manifest matches all 30 release files")
    print("PASS: every TTF, WOFF, and WOFF2 keeps all programming sequences literal by default")
    print(f"PASS: all files identify as Version {VERSION} in name/head metadata")
    print("PASS: wght axis 100-800 with 9 named instances; avar/STAT/gasp present")
    print("PASS: gasp requests grayscale/symmetric smoothing without contradictory grid fitting")
    print("PASS: hhea/OS2 typo metrics agree and transformed outlines contain no stale hint programs")
    print(f"PASS: 95 printable ASCII characters use a {ADVANCE}-unit advance")
    print("PASS: representative letters, digits, and symbols interpolate across weight")
    print(f"PASS: {len(ligature_names)} programming glyphs retain one-cell advances")
    print("PASS: 150 programming ligatures are optional under dlig; 3 legacy patterns stay literal")
    print("PASS: all 153 programming sequences are literal by default")
    print("PASS: four-character repeats remain literal instead of forming partial ligatures")
    print(f"PASS: Regular H stem {h_stem} units")
    print(f"PASS: H crossbar is optically lighter at {h_horizontal_stem} units and round glyphs overshoot")
    print(f"PASS: cap height {CAP_HEIGHT}, x-height {X_HEIGHT}, 1,363+ encoded characters")
    print(f"PASS: lowercase ascenders reach {LOWERCASE_ASCENDER_HEIGHT} without changing line metrics")
    print("PASS: established curves match the clean v1.230 geometry at Thin, Regular, and ExtraBold")
    print(
        f"PASS: {len(preserved_letter_numeral_glyphs)} encoded letter/numeral glyphs "
        "retain v1.240 advances/topology plus Regular bounds, bearings, and anchors"
    )
    print("PASS: O/o carry interpolation-compatible zero-style dots by default")
    print("PASS: slash and backslash retain their tall character inside the -80..738 band")
    print("PASS: k/r/t/w outlines match archived v1.251 at Thin, Regular, and ExtraBold")
    print("PASS: K uses the requested one-contour bridge-and-junction shape across the axis")
    print("PASS: CLN r retains 28-point topology, 50/80/150 stems, and 120/78 Regular sidebearings")
    print("PASS: CLN t/k/w silhouettes interpolate across the weight axis")
    print("PASS: j fitting and the redrawn k balance i-j-k-l inside the 579-unit advance")
    print("PASS: source-legible markup, punctuation, comments, and operators all stay literal by default")


if __name__ == "__main__":
    main()
