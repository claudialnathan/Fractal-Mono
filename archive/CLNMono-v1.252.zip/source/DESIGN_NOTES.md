# CLN Mono design notes

CLN Mono is designed and directed by Claudia Nathan. These notes describe the family through its own decisions, measurements, and release history.

## Design authorship

- Claudia Nathan owns the creative direction, letterform decisions, fitting, proportions, feature policy, specimens, and release approval for CLN Mono.
- The family is evaluated against its own brief: calm industrial character, strict monospace rhythm, clear coding symbols, compact interface fit, and distinctive letter construction.
- Required copyright notices for inherited OFL font-software components are isolated in `OFL.txt` and the font copyright field. They are legal redistribution notices, not the public design identity of CLN Mono.

## Core metrics

- Units per em: `1000`
- Fixed advance: `579`
- Cap height: `680`
- X-height: `528`
- Lowercase ascender height: `728`
- Lowercase descender depth: `-195`
- Regular vertical stem target: approximately `80`
- Weight axis: `100–800`

The lowercase ascender band increases apparent size at coding sizes without enlarging the x-height, caps, or line metrics. The `528/680` x-height-to-cap ratio remains intentionally generous.

## Letter construction

- `K` uses a plain stem, horizontal bridge, and outward junction before its diagonals.
- `k` stays open and is drawn directly into its intended cell fit.
- `r` uses a straight stem, rising shoulder, open counter, and diagonal terminal.
- `t` uses a compact short hook.
- `w` uses a pinched angular centre.
- `l` uses the flag-and-foot construction and a narrowed optical fit.
- `O`, `o`, and `0` use centre dots by default, with the lowercase dot scaled for counter space.

The `K/k/r/t/w` drawings remain protected style anchors across Thin, Regular, and ExtraBold. Validation locks `k/r/t/w` to the last approved CLN release and checks the new `K` construction explicitly across the weight axis.

## Fitting and symbols

- Every spacing glyph keeps the `579`-unit cell.
- Ink widths and sidebearings change; advances do not.
- The `j` shift balances the `i–j–k–l` rhythm.
- Slashes stay tall but fit inside the `-80..738` band.
- Braces, parentheses, angle brackets, arithmetic signs, dots, and underscore use a shared compact symbol language.

## Programming features

- All programming sequences remain literal by default.
- `150` joined drawings are available only through `dlig`.
- Three legacy patterns remain literal even when `dlig` is enabled.
- Longer repeated sequences are guarded so they do not form partial ligatures.
- Markup stays source-legible and each typed character retains its own cursor cell.

## Rasterisation

CLN Mono’s transformed outlines are deliberately unhinted. The `gasp` table requests grayscale and symmetric smoothing without grid fitting. Release proofs cover 11–16 px, light and dark surfaces, Regular and SemiBold, and browser captures at 1× and 2× device-pixel ratios.

## Release history

### 1.252

- Redraws uppercase `K` with a stem bridge and outward diagonal junction.
- Preserves the 579-unit cell, cap height, weight range, spacing, features, and all other approved outlines from 1.251.

### 1.251

- Makes Claudia Nathan’s authorship explicit across font metadata, documentation, factsheets, and specimens.
- Removes comparative-font presentation, reference-only proof scripts, and named fallback-font stacks.
- Keeps the approved 1.250 outlines, metrics, OpenType behavior, and rasterisation settings.

### 1.250

- Restored clean quadratic controls after the 1.240 tension experiment.
- Added dotted `O/o` defaults using interpolation-compatible contours.
- Preserved CLN’s approved fitting, metrics, weight mapping, and protected letterforms.

### 1.240

- Raised the lowercase ascender reach from `680` to `728`.
- Kept cap height, x-height, descenders, advance, UPM, and line metrics unchanged.
- Introduced a contour-tension experiment later removed in 1.250.

## Release rules

- Do not change the fixed advance to solve optical spacing.
- Keep programming ligatures opt-in.
- Preserve `K/k/r/t/w` as style anchors, including the 1.252 uppercase `K` junction.
- Judge changes in real coding-size rendering as well as outline inspection.
- Keep CLN Mono’s own design language at the centre of every public specimen.
